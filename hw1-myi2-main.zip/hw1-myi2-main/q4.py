"""
Question 4
"""


def math_game():
    pass


def main():
    math_game()


if __name__ == "__main__":
    main()
