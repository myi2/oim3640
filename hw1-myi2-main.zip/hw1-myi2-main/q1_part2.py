"""
Question 1, part 2
"""





def main():
    """
    """
    x_start = 0
    y_start = 0
    steps = 100
    print(f"The drunkard started from ({x_start}, {y_start}).")
    
    # Your functions should calculate x_end, y_end, and distance. Call the functions and then uncomment the next line.

    # print(f"After {steps} intersections, he is at ({x_end}, {y_end}), which is {distance} blocks from where he started.")


if __name__ == '__main__':
    main()