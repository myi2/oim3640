# Assignment 1

**Please read [Code Grading Rubric](https://github.com/oim3640/resources/blob/main/code_grading_rubric.md) carefully before you start this assignment.**

There are 6 Python files in this folder: *[q1.py](q1.py)*, *[q1_part2.py](q1_part2.py)*, *[q2.py](q2.py)*, *[q3.py](q3.py)*, *[q4.py](q4.py)*, and *[q5.py](q5.py)*. Please use these files to finish the following programs.

1. (20 points) John is drunk today. He starts from a given starting point, walks in a grid of streets **randomly** picks one of four directions and stumbles to the next intersection, then again **randomly** picks one of four directions, and so on. You might think that on average John does not move very far because the choices cancel each other out, but that is actually not the case.

    1. Finish the function that returns the ending point and the [Manhattan distance](https://en.wikipedia.org/wiki/Taxicab_geometry) after `n` intersections.
    2. In *[q1_part2.py](q1_part2.py)*, break down the given function `drunkard_walk` in *[q1.py](q1.py)* into two separate functions which should achieve the same goal. Note that the output might not be the same, unless the same `random.seed()` is used.

2. (20 points) Use `turtle` library to visually represent John's walk from the previous question. The starting and ending location should be highlighted in <span style="color:red;">red</span>. Note that the drawn path does not have to be the same as the one calculated in Question 1, unless the same `random.seed()` is used.

3. (20 points) Write a Python program to solve the following problems:

   1. John is taking out a $30000 multi-year fixed-rate mortgage to purchase a new car. The interest rate is 6.9% and the monthly payment is $510.04. Write a function, `total()`, that takes in total pinncipal, interest rate and monthly payment as arguments, and calculates the total amount that John will have to pay over the life of the mortgage, ignoring the overpayment that occurs in the last month.
   
        **Hint 1**: You can use the following formula to calculate the remaining principal of any month:
        > Remaining principal of this month = Remaining principal of last month * (1 + Rate / 12) - Monthly payment. 
     
        **Hint 2**: The total amount that John will have to pay over the life of the mortgage, which is the answer to this question, is $36722.88.

        **Hint 3**: Notice the number of months is not given - use this as a hint to choose the loop type between `while` and `for`.

   2. John decides to pay an extra amount for the first 12 months of the mortgage to end it earlier. Create a new function, `total_2()`, that takes in total pinncipal, interest rate, monthly payment, the extra payment amount as arguments and prints the total amount paid and the number of months, assuming only first paying extra amount for the first 12 months. (For example, if the extra payment is $200, you should get a total payment of $36062.64 over 66 months, which actually is not a lot less.)
   
   3. John decides to pay an extra amount for a certain period of time, not necessarily the first 12 months. Create a new function, `total_3()`, that takes in total pinncipal, interest rate, monthly payment, the extra payment amount, starting month, and ending month as arguments, and calculates the total amount that John will have to pay over the life of the mortgage. For example, the extra month payment of $300.00 could start from the 13th month and end at the 36th month.
   
   4. Create a new function, `total_4()` (based on previous function, `total_3()` - you don't have to call `total_3()` in `total_4()`), that **prints** the month number, total paid amount so far, and the remaining principal every month **in a nice format**. For example, if John starts to pay extra month payment of $300.00 from the 13th month to the 36th month, the output should look like this:
        ```
         1, $   510.04, $ 29662.46
         2, $  1020.08, $ 29322.98
         3, $  1530.12, $ 28981.55
        ...
        11, $  5610.44, $ 26178.45
        12, $  6120.48, $ 25818.94
        13, $  6930.52, $ 25157.36
        ...
        35, $ 24751.40, $  9600.26
        36, $ 25561.44, $  8845.42
        37, $ 26071.48, $  8386.24
        ...
        53, $ 34232.12, $   669.77
        54, $ 34742.16, $   163.58
        55, $ 35252.20, $  -345.52
        ```
   
   5. (Optional) Create a new function, `total_4_fixed()` (based on previous function), that prints almost the same table, but corrects for the overpayment that occurs in the last month.

4. (20 points) John's kids want to practice math at home. Write a Python program to help them.

   1. Your program should **randomly** generate simple arithmetic problems, read in the answer from the user, and then check whether the user's answer is right or wrong, until the user answers correctly multiple times **in a row**.

      More specifically, your program should be able to generate simple addition problems, which involve adding two 3-digit integers (that is, the numbers `100` to `999`). The user should be asked to answer each question. Your program should determine whether the answer is correct and provide the user with an appropriate message to inform them. Your program should continue to provide users with problems until the user corrects 3 problems **in a row**.

      Below is a sample run of the program in terminal/command prompt:

      ![](https://i.imgur.com/6dPWT7n.png)

   2. (Optional) Add more problem types (subtraction, multiplication, division, etc.) and expand beyond arithmetic. Be creative and have fun!

5. (20 points) Design a programming problem that incorporates all the programming concepts we've learned thus far, such as variables, types, functions, conditional statements, and iterations, without the use of data structures like lists or dictionaries (unless you have a strong grasp of these). Be creative and think of a real-world scenario that people can relate to. Please avoid using ChatGPT or copying from any external sources.

    Please include the problem description at the top of the Python file. Then create function(s) to solve the problem you've developed.