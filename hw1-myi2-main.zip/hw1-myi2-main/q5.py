"""
Question 5

The problem description goes here.
"""