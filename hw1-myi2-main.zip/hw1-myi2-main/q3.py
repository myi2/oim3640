"""
Question 3

Note: There should be only one main function and one if __name__ in one Python module.
"""


def total(principal, rate, monthly_payment):
    pass


def main():
    principal = 30000
    rate = 0.069
    payment = 510.04
    total(principal, rate, payment)
    # You should add more code here


if __name__ == "__main__":
    main()
