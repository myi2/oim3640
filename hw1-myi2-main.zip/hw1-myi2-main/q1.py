"""
Question 1

Instructions:
- Write your code for the function below, drunkard_walk.
- Be sure to delete the 'pass' line before writing your code.
- You may create additional helper functions if needed.
- Before writing your code, read the main() function to understand how this function is called.
- Don't forget docstrings.
"""

def drunkard_walk(x, y, n):
    pass


def main():
    """
    Please do not change the code below.
    """
    x_start = 0
    y_start = 0
    steps = 100
    print(f"The drunkard started from ({x_start}, {y_start}).")
    x_end, y_end, distance = drunkard_walk(x_start, y_start, steps)
    print(f"After {steps} intersections, he is at ({x_end}, {y_end}), which is {distance} blocks from where he started.")


if __name__ == '__main__':
    main()