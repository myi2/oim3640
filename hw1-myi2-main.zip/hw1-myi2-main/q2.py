"""
Question 2
"""
